#!/usr/bin/bash
cd /www/wwwroot/
zip -r lets_chat.zip vbs-students-site/
cp lets_chat.zip /www/wwwroot/vbs-students-site/